import { useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";
import { ProjectState, Character } from '../types';
import { generateId, cleanToken } from '../utils/helpers';
import { GLOBAL_STYLES } from '../constants/presets';
import { callGeminiAPI } from '../utils/geminiUtils';

export function useCharacterLogic(
    state: ProjectState,
    updateStateAndRecord: (updater: (prevState: ProjectState) => ProjectState) => void,
    userApiKey: string | null,
    setApiKeyModalOpen: (open: boolean) => void
) {
    const updateCharacter = useCallback((id: string, updates: Partial<Character>) => {
        updateStateAndRecord(s => ({
            ...s,
            characters: s.characters.map(c => c.id === id ? { ...c, ...updates } : c)
        }));
    }, [updateStateAndRecord]);

    const addCharacter = useCallback(() => {
        const newChar: Character = {
            id: generateId(),
            name: '',
            description: '',
            masterImage: null,
            faceImage: null,
            bodyImage: null,
            sideImage: null,
            backImage: null,
            props: [
                { id: generateId(), name: '', image: null },
                { id: generateId(), name: '', image: null },
                { id: generateId(), name: '', image: null },
            ],
            isDefault: false,
            isAnalyzing: false,
        };
        updateStateAndRecord(s => ({
            ...s,
            characters: [...s.characters, newChar]
        }));
    }, [updateStateAndRecord]);

    const deleteCharacter = useCallback((id: string) => {
        if (state.characters.length <= 1) {
            alert("Bạn cần ít nhất 1 nhân vật.");
            return;
        }
        setTimeout(() => {
            if (confirm("Bạn có chắc muốn xóa nhân vật này?")) {
                updateStateAndRecord(s => ({
                    ...s,
                    characters: s.characters.filter(c => c.id !== id)
                }));
            }
        }, 100);
    }, [state.characters.length, updateStateAndRecord]);

    const setDefaultCharacter = useCallback((id: string) => {
        updateStateAndRecord(s => ({
            ...s,
            characters: s.characters.map(c => ({
                ...c,
                isDefault: c.id === id
            }))
        }));
    }, [updateStateAndRecord]);

    const pollCharacterWorkflows = useCallback(async (
        charId: string,
        token: string,
        faceWorkflowId: string | null,
        bodyWorkflowId: string | null,
        sidePrompt?: string,
        backPrompt?: string
    ) => {
        const cleanedToken = cleanToken(token);
        let faceUrl: string | null = null;
        let bodyUrl: string | null = null;
        let attempts = 0;
        const maxAttempts = 40;

        const pollWorkflow = async (workflowId: string): Promise<string | null> => {
            try {
                const res = await fetch('http://localhost:3001/api/proxy/google/workflow/status', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ token: cleanedToken, workflowId })
                });
                const data = await res.json();
                if (data.state === 'SUCCEEDED' && data.media && data.media.length > 0) {
                    const m = data.media[0];
                    return m.fifeUrl || m.url || m.image?.fifeUrl || null;
                }
                if (data.state === 'FAILED') return null;
                return 'pending';
            } catch (err) {
                console.error("Poll error:", err);
                return null;
            }
        };

        while (attempts < maxAttempts && (!faceUrl || !bodyUrl)) {
            await new Promise(r => setTimeout(r, 3000));
            attempts++;
            if (faceWorkflowId && !faceUrl) {
                const result = await pollWorkflow(faceWorkflowId);
                if (result && result !== 'pending') faceUrl = result;
            }
            if (bodyWorkflowId && !bodyUrl) {
                const result = await pollWorkflow(bodyWorkflowId);
                if (result && result !== 'pending') bodyUrl = result;
            }

            // Intermediate update to show partial progress
            if (faceUrl || bodyUrl) {
                updateCharacter(charId, {
                    faceImage: faceUrl || undefined,
                    bodyImage: bodyUrl || undefined,
                });
            }

            if ((faceUrl || !faceWorkflowId) && (bodyUrl || !bodyWorkflowId)) break;
        }

        // --- PHASE 2 (Genyu): If Body is ready, trigger Side/Back ---
        if (bodyUrl && sidePrompt && backPrompt) {
            const styleMapping: Record<string, string> = {
                'cinematic-realistic': 'Photorealistic',
                '3d-pixar': '3D Model / Character Sheet',
                'anime-makoto': 'Anime',
                'vintage-film': 'Photorealistic',
                'cyberpunk': 'Cinematic',
                'watercolor': 'Watercolor',
                'dark-fantasy': 'Cinematic'
            };
            const genyuStyle = styleMapping[state.stylePrompt] || 'No Style';

            const callProxy = async (prompt: string): Promise<string | null> => {
                try {
                    const res = await fetch('http://localhost:3001/api/proxy/genyu/image', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            token: cleanedToken,
                            recaptchaToken: state.recaptchaToken,
                            prompt,
                            aspect: "IMAGE_ASPECT_RATIO_PORTRAIT",
                            style: genyuStyle,
                            imageUrl: bodyUrl // USE BODY AS REFERENCE
                        })
                    });
                    const d = await res.json();
                    if (!res.ok) return null;
                    if (d.media && d.media.length > 0) {
                        const m = d.media[0];
                        return m.fifeUrl || m.url || (m.image?.generatedImage?.encodedImage ? `data:image/jpeg;base64,${m.image.generatedImage.encodedImage}` : null);
                    }
                    return null;
                } catch (e) { return null; }
            };

            const [sideUrl, backUrl] = await Promise.all([
                callProxy(sidePrompt),
                callProxy(backPrompt)
            ]);

            updateCharacter(charId, {
                sideImage: sideUrl || undefined,
                backImage: backUrl || undefined,
                workflowStatus: 'succeeded' as const,
                faceWorkflowId: undefined,
                bodyWorkflowId: undefined,
                isAnalyzing: false
            });
        } else {
            updateCharacter(charId, {
                workflowStatus: attempts >= maxAttempts ? 'failed' : 'succeeded',
                isAnalyzing: false
            });
        }
    }, [updateCharacter, state.stylePrompt, state.recaptchaToken, updateStateAndRecord]);

    const handleMasterImageUpload = useCallback(async (id: string, image: string) => {
        const rawApiKey = userApiKey || (process.env as any).API_KEY;
        const apiKey = typeof rawApiKey === 'string' ? rawApiKey.trim() : rawApiKey;
        updateCharacter(id, { masterImage: image, isAnalyzing: true });

        if (!apiKey) {
            updateCharacter(id, { isAnalyzing: false });
            setApiKeyModalOpen(true);
            return;
        }

        try {
            const ai = new GoogleGenAI({ apiKey });
            let data: string;
            let mimeType: string = 'image/jpeg';

            if (image.startsWith('data:')) {
                const [header, base64Data] = image.split(',');
                data = base64Data;
                mimeType = header.match(/:(.*?);/)?.[1] || 'image/jpeg';
            } else {
                const proxyUrl = `http://localhost:3001/api/proxy/fetch-image?url=${encodeURIComponent(image)}`;
                const imgRes = await fetch(proxyUrl);
                if (!imgRes.ok) throw new Error(`Fetch failed`);
                const blob = await imgRes.blob();
                mimeType = blob.type;
                data = await new Promise<string>((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
                    reader.onerror = reject;
                    reader.readAsDataURL(blob);
                });
            }

            const analyzePrompt = `Analyze this character. Return JSON: {"name": "Suggest Name", "description": "Vietnamese description physical features, clothing, style, colors."}`;
            const analysisRes = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: { parts: [{ inlineData: { data, mimeType } }, { text: analyzePrompt }] },
                config: {
                    responseMimeType: "application/json",
                    thinkingConfig: { thinkingLevel: 'low' }
                }
            });

            let json = { name: "", description: "" };
            try {
                json = JSON.parse(analysisRes.text.replace(/```json/g, '').replace(/```/g, '').trim());
            } catch (e) {
                console.error("JSON parse error", e);
            }

            updateCharacter(id, { name: json.name, description: json.description });

            const genyuToken = state.genyuToken;
            const currentStyle = GLOBAL_STYLES.find(s => s.value === state.stylePrompt)?.prompt || "Cinematic photorealistic, 8k, high quality";

            const consistencyInstruction = `
            **MANDATORY CONSISTENCY:** 
            - BACKGROUND: MUST be a Pure Solid White Studio Background. 
            - CHARACTER: The character's face, hair, and clothing MUST be exactly as seen in the reference.
            - MASTER REFERENCE STYLE: You must strictly adhere to the following artistic style for all character details: "${currentStyle}".
            - LIGHTING: Professional studio lighting with rim lights for clear character silhouette.
            - QUALITY: 8K resolution, hyper-detailed, clean sharp focus.
            `.trim();

            const facePrompt = `${consistencyInstruction}\n\n(STRICT CAMERA: EXTREME CLOSE-UP - FACE ID ON WHITE BACKGROUND) Generate a highly detailed Face ID close-up of this character: ${json.description}. Focus on capturing the exact facial features and expression from the reference. The background must be pure solid white.`;
            const bodyPrompt = `${consistencyInstruction}\n\n(STRICT CAMERA: FULL BODY HEAD-TO-TOE WIDE SHOT ON WHITE BACKGROUND) Generate a Full Body character design sheet (Front View, T-Pose or A-Pose). MUST CAPTURE HEAD-TO-TOE INCLUDING VISIBLE FEET. Description: ${json.description}. The clothing must match the reference image's color and texture exactly. The background must be pure solid white.`;
            const sidePrompt = `${consistencyInstruction}\n\n(STRICT CAMERA: FULL BODY HEAD-TO-TOE SIDE PROFILE ON WHITE BACKGROUND) Generate a Full Body Side Profile. MUST CAPTURE HEAD-TO-TOE INCLUDING VISIBLE FEET. Description: ${json.description}. Maintain the same clothing and body proportions as the body view. The background must be pure solid white.`;
            const backPrompt = `${consistencyInstruction}\n\n(STRICT CAMERA: FULL BODY HEAD-TO-TOE BACK VIEW ON WHITE BACKGROUND) Generate a Full Body Back View. MUST CAPTURE HEAD-TO-TOE INCLUDING VISIBLE FEET. Description: ${json.description}. Ensure the back of the clothing reflects the design seen in the front. The background must be pure solid white.`;

            if (apiKey) {
                const model = state.imageModel || 'gemini-2.5-flash-image';

                // --- PHASE 1: Generate Face and Front Body ---
                const [faceUrl, bodyUrl] = await Promise.all([
                    callGeminiAPI(apiKey, facePrompt, "1:1", model, image),
                    callGeminiAPI(apiKey, bodyPrompt, "9:16", model, image),
                ]);

                // Update with Phase 1 results immediately
                updateCharacter(id, {
                    faceImage: faceUrl || undefined,
                    bodyImage: bodyUrl || undefined,
                });

                // --- PHASE 2: Side and Back views using generated Front Body as REFERENCE ---
                if (bodyUrl) {
                    const [sideUrl, backUrl] = await Promise.all([
                        callGeminiAPI(apiKey, sidePrompt, "9:16", model, bodyUrl),
                        callGeminiAPI(apiKey, backPrompt, "9:16", model, bodyUrl)
                    ]);

                    updateCharacter(id, {
                        sideImage: sideUrl || undefined,
                        backImage: backUrl || undefined,
                        isAnalyzing: false,
                    });
                } else {
                    updateCharacter(id, { isAnalyzing: false });
                }

            } else if (genyuToken) {
                const callProxy = async (prompt: string, aspect: string, refImage?: string): Promise<string | { workflowId: string } | null> => {
                    const styleMapping: Record<string, string> = {
                        'cinematic-realistic': 'Photorealistic',
                        '3d-pixar': '3D Model / Character Sheet',
                        'anime-makoto': 'Anime',
                        'vintage-film': 'Photorealistic',
                        'cyberpunk': 'Cinematic',
                        'watercolor': 'Watercolor',
                        'dark-fantasy': 'Cinematic'
                    };
                    const genyuStyle = styleMapping[state.stylePrompt] || 'No Style';

                    const body: any = {
                        token: genyuToken,
                        recaptchaToken: state.recaptchaToken,
                        prompt,
                        aspect,
                        style: genyuStyle
                    };

                    if (refImage) {
                        body.imageUrl = refImage; // Genyu proxy usually supports imageUrl as reference
                    }

                    const res = await fetch('http://localhost:3001/api/proxy/genyu/image', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(body)
                    });
                    const d = await res.json();
                    if (!res.ok) return null;
                    if (d.media && d.media.length > 0) {
                        const m = d.media[0];
                        if (m.fifeUrl || m.url) return m.fifeUrl || m.url;
                        if (m.image?.generatedImage?.encodedImage) return `data:image/jpeg;base64,${m.image.generatedImage.encodedImage}`;
                        if (m.workflowId) return { workflowId: m.workflowId };
                    }
                    return null;
                };

                // Phase 1 for Genyu
                const [faceResult, bodyResult] = await Promise.all([
                    callProxy(facePrompt, "IMAGE_ASPECT_RATIO_SQUARE"),
                    callProxy(bodyPrompt, "IMAGE_ASPECT_RATIO_PORTRAIT")
                ]);

                const faceUrl = typeof faceResult === 'string' ? faceResult : null;
                const bodyUrl = typeof bodyResult === 'string' ? bodyResult : null;
                const faceWorkflowId = typeof faceResult === 'object' ? faceResult?.workflowId : null;
                const bodyWorkflowId = typeof bodyResult === 'object' ? bodyResult?.workflowId : null;

                if (faceWorkflowId || bodyWorkflowId) {
                    updateStateAndRecord(s => ({
                        ...s,
                        characters: s.characters.map(c => c.id === id ? {
                            ...c,
                            faceWorkflowId: faceWorkflowId || undefined,
                            bodyWorkflowId: bodyWorkflowId || undefined,
                            workflowStatus: 'active' as const,
                            isAnalyzing: false
                        } : c)
                    }));
                    // Updated polling to trigger Phase 2
                    pollCharacterWorkflows(id, genyuToken, faceWorkflowId, bodyWorkflowId, sidePrompt, backPrompt);
                } else {
                    updateCharacter(id, { faceImage: faceUrl || undefined, bodyImage: bodyUrl || undefined });
                    // If no workflow (image returned immediately), trigger Phase 2 for Side/Back
                    if (bodyUrl) {
                        const [sideRes, backRes] = await Promise.all([
                            callProxy(sidePrompt, "IMAGE_ASPECT_RATIO_PORTRAIT", bodyUrl),
                            callProxy(backPrompt, "IMAGE_ASPECT_RATIO_PORTRAIT", bodyUrl)
                        ]);
                        // Genyu might return workflows for these too, but for simplicity we assume sync or let poll handle it if we genericized it
                        // Simplified for now: assume sync or just set them if string
                        updateCharacter(id, {
                            sideImage: typeof sideRes === 'string' ? sideRes : undefined,
                            backImage: typeof backRes === 'string' ? backRes : undefined,
                            isAnalyzing: false
                        });
                    } else {
                        updateCharacter(id, { isAnalyzing: false });
                    }
                }
            }
        } catch (error: any) {
            console.error("Analysis Failed", error);
            updateCharacter(id, { isAnalyzing: false });
        }
    }, [userApiKey, updateCharacter, setApiKeyModalOpen, state.imageModel, state.genyuToken, state.stylePrompt, state.recaptchaToken, pollCharacterWorkflows]);

    return {
        updateCharacter,
        addCharacter,
        deleteCharacter,
        setDefaultCharacter,
        handleMasterImageUpload
    };
}
